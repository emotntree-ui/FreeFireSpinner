package com.ravi.freespinner;

import android.app.*;
import android.content.*;
import android.os.*;
import androidx.core.app.NotificationCompat;

public class RunnerService extends Service {
    public static final String ACTION_START = "RUNNER_START";
    public static final String ACTION_STOP = "RUNNER_STOP";
    private static final int ID = 7711;

    @Override public void onCreate() {
        super.onCreate();
        String channel = "runner";
        NotificationManager nm = getSystemService(NotificationManager.class);
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(new NotificationChannel(channel, "Python Runner",
                    NotificationManager.IMPORTANCE_LOW));
        }
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopForeground(STOP_FOREGROUND_REMOVE);
            stopSelf();
            return START_NOT_STICKY;
        }
        Notification n = new NotificationCompat.Builder(this, "runner")
                .setSmallIcon(android.R.drawable.stat_sys_download_done)
                .setContentTitle("Free Fire Spinner")
                .setContentText("Python runner is active")
                .setOngoing(true)
                .setCategory(NotificationCompat.CATEGORY_SERVICE)
                .build();
        startForeground(ID, n);
        return START_STICKY;
    }

    @Override public android.os.IBinder onBind(Intent intent) { return null; }
}

package com.ravi.freespinner;

import android.app.*;
import android.os.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import com.chaquo.python.PyObject;
import com.chaquo.python.Python;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.*;

public class MainActivity extends AppCompatActivity {
    TextView logView, statusText, statusDot, runtimeText;
    LinearLayout fileList;
    EditText inputBox, commandBox;
    File root, projectDir, outputDir, inputFile, logFile;
    volatile boolean running = false;
    ExecutorService exec = Executors.newSingleThreadExecutor();
    Handler handler = new Handler(Looper.getMainLooper());
    ActivityResultLauncher<Intent> picker;
    ActivityResultLauncher<Intent> saveLauncher;
    File savePendingFile;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        bind();
        initDirs();
        requestNotification();
        seedProject();
        refreshFiles();
        picker = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), r -> {
            if (r.getResultCode() == RESULT_OK && r.getData() != null) importPicked(r.getData());
        });
        saveLauncher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), r -> {
            if (r.getResultCode() == RESULT_OK && r.getData() != null && savePendingFile != null) {
                try (InputStream in = new FileInputStream(savePendingFile);
                     OutputStream out = getContentResolver().openOutputStream(r.getData().getData())) {
                    byte[] b = new byte[8192]; int n;
                    while ((n=in.read(b)) > 0) out.write(b,0,n);
                    Toast.makeText(this,"File saved successfully.",Toast.LENGTH_SHORT).show();
                } catch(Exception e) {
                    Toast.makeText(this,"Save failed: "+e.getMessage(),Toast.LENGTH_LONG).show();
                }
            }
            savePendingFile = null;
        });
        startLogPump();
    }

    void bind() {
        logView=findViewById(R.id.logView); statusText=findViewById(R.id.statusText);
        statusDot=findViewById(R.id.statusDot); runtimeText=findViewById(R.id.runtimeText);
        fileList=findViewById(R.id.fileList); inputBox=findViewById(R.id.inputBox);
        commandBox=findViewById(R.id.commandBox);
        findViewById(R.id.startButton).setOnClickListener(v -> startRunner());
        findViewById(R.id.stopButton).setOnClickListener(v -> stopRunner());
        findViewById(R.id.restartButton).setOnClickListener(v -> { stopRunner(); handler.postDelayed(this::startRunner,500); });
        findViewById(R.id.sendButton).setOnClickListener(v -> sendInput());
        findViewById(R.id.runCommandButton).setOnClickListener(v -> runCommand());
        findViewById(R.id.refreshButton).setOnClickListener(v -> refreshFiles());
        findViewById(R.id.adminButton).setOnClickListener(v -> adminLogin());
    }

    void initDirs() {
        root = new File(getFilesDir(),"spinner");
        projectDir = new File(root,"project");
        outputDir = new File(root,"output");
        inputFile = new File(root,"stdin.txt");
        logFile = new File(root,"runner.log");
        projectDir.mkdirs(); outputDir.mkdirs();
    }

    void seedProject() {
        File runner = new File(projectDir,"runner.py");
        if (!runner.exists()) {
            try (InputStream in=getAssets().open("runner.py"); FileOutputStream out=new FileOutputStream(runner)) {
                byte[] b=new byte[8192]; int n; while((n=in.read(b))>0) out.write(b,0,n);
            } catch(Exception e) { append("Seed error: "+e); }
        }
    }

    void requestNotification() {
        if (Build.VERSION.SDK_INT>=33 && ContextCompat.checkSelfPermission(this,"android.permission.POST_NOTIFICATIONS")
                != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"},88);
    }

    void startRunner() {
        if(running) return;
        running=true; setStatus("RUNNING", Color.rgb(57,229,140));
        append("Starting Python runner...");
        try { new FileOutputStream(inputFile,false).close(); } catch(Exception ignored){}
        Intent s=new Intent(this,RunnerService.class);
        ContextCompat.startForegroundService(this,s);
        exec.submit(() -> {
            try {
                Python py=Python.getInstance();
                PyObject mod=py.getModule("bridge");
                mod.callAttr("run_file", projectDir.getAbsolutePath(), "runner.py",
                        outputDir.getAbsolutePath(), inputFile.getAbsolutePath(), logFile.getAbsolutePath());
            } catch(Exception e) { append("Python error: "+e); }
            finally {
                running=false;
                handler.post(() -> setStatus("STOPPED", Color.rgb(255,200,87)));
                stopService(new Intent(this,RunnerService.class));
            }
        });
    }

    void stopRunner() {
        running=false;
        append("Stop requested.");
        stopService(new Intent(this,RunnerService.class));
    }

    void sendInput() {
        String s=inputBox.getText().toString();
        if(s.isEmpty()) return;
        try {
            FileWriter w=new FileWriter(inputFile,true); w.write(s.replace("\n","")+"\\n"); w.close();
            append("> "+s);
            inputBox.setText("");
        } catch(Exception e){ append("Input error: "+e); }
    }

    void runCommand() {
        String cmd=commandBox.getText().toString().trim();
        if(cmd.isEmpty()) return;
        append("$ "+cmd);
        exec.submit(() -> {
            try {
                Process p=new ProcessBuilder("/system/bin/sh","-c",cmd)
                        .directory(root).redirectErrorStream(true).start();
                BufferedReader br=new BufferedReader(new InputStreamReader(p.getInputStream()));
                String line; while((line=br.readLine())!=null){ String x=line; handler.post(()->append(x)); }
                int code=p.waitFor(); handler.post(()->append("[exit "+code+"]"));
            } catch(Exception e){ handler.post(()->append("Command error: "+e)); }
        });
        commandBox.setText("");
    }

    void startLogPump() {
        handler.postDelayed(new Runnable(){ public void run(){
            if(logFile!=null && logFile.exists()){
                try{
                    String s=readText(logFile);
                    if(!s.isEmpty()) logView.setText(s);
                }catch(Exception ignored){}
            }
            handler.postDelayed(this,350);
        }},350);
    }

    void append(String s) {
        handler.post(() -> { logView.append(s+"\\n"); });
    }

    void setStatus(String s,int c) {
        statusText.setText(s); statusText.setTextColor(c); statusDot.setTextColor(c);
    }

    void refreshFiles() {
        fileList.removeAllViews();
        ArrayList<File> all=new ArrayList<>();
        collect(projectDir,all); collect(outputDir,all);
        for(File f:all){
            LinearLayout row=new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(8,10,8,10);
            TextView name=new TextView(this); name.setText("• "+f.getAbsolutePath().replace(root.getAbsolutePath()+"/",""));
            name.setTextColor(Color.WHITE); name.setLayoutParams(new LinearLayout.LayoutParams(0,-2,1));
            row.addView(name);
            Button view=new Button(this); view.setText("VIEW"); row.addView(view);
            Button share=new Button(this); share.setText("SHARE"); row.addView(share);
            Button save=new Button(this); save.setText("SAVE"); row.addView(save);
            view.setOnClickListener(v -> viewFile(f));
            share.setOnClickListener(v -> shareFile(f));
            save.setOnClickListener(v -> saveFile(f));
            fileList.addView(row);
        }
    }

    void collect(File d,List<File> out){
        File[] fs=d.listFiles(); if(fs==null)return;
        for(File f:fs){ if(f.isDirectory()) collect(f,out); else out.add(f); }
    }

    void viewFile(File f) {
        if(f.length()>1024*1024){ Toast.makeText(this,"File too large for viewer; use SHARE.",Toast.LENGTH_SHORT).show(); return; }
        try {
            String s=readText(f);
            new AlertDialog.Builder(this).setTitle(f.getName()).setMessage(s).setPositiveButton("CLOSE",null).show();
        }catch(Exception e){ Toast.makeText(this,"Cannot view file",Toast.LENGTH_SHORT).show(); }
    }

    void shareFile(File f) {
        if(!f.isFile()) return;
        try {
            android.net.Uri uri = androidx.core.content.FileProvider.getUriForFile(
                    this, getPackageName()+".fileprovider", f);
            Intent i=new Intent(Intent.ACTION_SEND);
            i.setType(getContentResolver().getType(uri) != null ?
                    getContentResolver().getType(uri) : "application/octet-stream");
            i.putExtra(Intent.EXTRA_STREAM, uri);
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(i,"Share file"));
        } catch(Exception e) {
            Toast.makeText(this,"Share failed: "+e.getMessage(),Toast.LENGTH_LONG).show();
        }
    }

    void saveFile(File f) {
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.setType("application/octet-stream");
        i.putExtra(Intent.EXTRA_TITLE, f.getName());
        savePendingFile = f;
        saveLauncher.launch(i);
    }

    void adminLogin() {
        LinearLayout box=new LinearLayout(this); box.setPadding(40,10,40,0); box.setOrientation(LinearLayout.VERTICAL);
        EditText user=new EditText(this); user.setHint("Admin username"); box.addView(user);
        EditText pass=new EditText(this); pass.setHint("Admin password"); pass.setInputType(0x81); box.addView(pass);
        new AlertDialog.Builder(this).setTitle("ADMIN LOGIN").setView(box)
            .setPositiveButton("LOGIN",(d,w)->{
                if("admin".equals(user.getText().toString()) && "Ravi@12345".equals(pass.getText().toString())) adminPanel();
                else Toast.makeText(this,"Invalid admin credentials",Toast.LENGTH_SHORT).show();
            }).setNegativeButton("CANCEL",null).show();
    }

    void adminPanel() {
        String[] items={"Upload runner/source files","Open project folder","Open output folder","Change admin password"};
        new AlertDialog.Builder(this).setTitle("ADMIN PANEL").setItems(items,(d,which)->{
            if(which==0) pickFiles();
            else if(which==1) openFolder(projectDir);
            else if(which==2) openFolder(outputDir);
            else changePasswordNotice();
        }).show();
    }

    void pickFiles() {
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.setType("*/*"); i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);
        i.addCategory(Intent.CATEGORY_OPENABLE); picker.launch(i);
    }

    void importPicked(Intent data) {
        try {
            if(data.getClipData()!=null){
                for(int i=0;i<data.getClipData().getItemCount();i++) copyUri(data.getClipData().getItemAt(i).getUri());
            } else copyUri(data.getData());
            append("Admin: project files imported.");
            refreshFiles();
        }catch(Exception e){ append("Import error: "+e); }
    }

    void copyUri(Uri u)throws Exception{
        String name="uploaded_"+System.currentTimeMillis()+".py";
        android.database.Cursor c=getContentResolver().query(u,new String[]{"_display_name"},null,null,null);
        if(c!=null){ if(c.moveToFirst()) name=c.getString(0); c.close(); }
        File dest=new File(projectDir,name.replace("/","_"));
        try(InputStream in=getContentResolver().openInputStream(u); OutputStream out=new FileOutputStream(dest)){
            byte[] b=new byte[8192]; int n; while((n=in.read(b))>0)out.write(b,0,n);
        }
    }

    String readText(File f) throws Exception {
        StringBuilder sb = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(f), StandardCharsets.UTF_8))) {
            String line;
            while ((line = br.readLine()) != null) sb.append(line).append('\\n');
        }
        return sb.toString();
    }

    void openFolder(File f){ Toast.makeText(this,"App folder: "+f.getAbsolutePath(),Toast.LENGTH_LONG).show(); }
    void changePasswordNotice(){ Toast.makeText(this,"Password change can be wired to encrypted preferences in the hardening pass.",Toast.LENGTH_LONG).show(); }

    @Override protected void onDestroy(){ super.onDestroy(); exec.shutdownNow(); }
}

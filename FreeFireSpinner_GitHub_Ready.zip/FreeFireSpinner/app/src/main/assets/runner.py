# Demo runner bundled inside the APK.
# Replace this file through the Admin panel with your own generic Python project.
import os, time

print("Bundled runner is working.")
print("Project:", os.environ.get("SPINNER_PROJECT_DIR"))
print("Output:", os.environ.get("SPINNER_OUTPUT_DIR"))

name = input("Enter a name: ").strip()
if not name:
    name = "Guest"

out = os.path.join(os.environ["SPINNER_OUTPUT_DIR"], "result.txt")
with open(out, "w", encoding="utf-8") as f:
    f.write("Hello " + name + "\n")
    f.write("Python runner completed successfully.\n")

print("Created:", out)
time.sleep(0.2)
print("Done.")

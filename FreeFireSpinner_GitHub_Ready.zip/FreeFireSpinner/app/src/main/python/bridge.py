import os, sys, time, traceback, runpy, threading

class FileInput:
    def __init__(self, path):
        self.path = path
        self.pos = 0
    def readline(self, *args, **kwargs):
        while True:
            try:
                with open(self.path, "r", encoding="utf-8") as f:
                    f.seek(self.pos)
                    data = f.read()
                    if "\n" in data:
                        line = data[:data.index("\n")+1]
                        self.pos += len(line)
                        return line
            except FileNotFoundError:
                pass
            time.sleep(0.15)

class Tee:
    def __init__(self, path):
        self.path = path
        self.lock = threading.Lock()
    def write(self, s):
        if s:
            with self.lock:
                with open(self.path, "a", encoding="utf-8") as f:
                    f.write(s)
                    f.flush()
    def flush(self): pass
    def isatty(self): return False

def run_file(project, filename, output, input_path, log_path):
    os.makedirs(project, exist_ok=True)
    os.makedirs(output, exist_ok=True)
    os.chdir(project)
    if project not in sys.path:
        sys.path.insert(0, project)
    os.environ["SPINNER_OUTPUT_DIR"] = output
    os.environ["SPINNER_PROJECT_DIR"] = project
    os.environ["SPINNER_INPUT_FILE"] = input_path
    os.environ["SPINNER_LOG_FILE"] = log_path
    open(log_path, "w", encoding="utf-8").close()
    sys.stdout = Tee(log_path)
    sys.stderr = Tee(log_path)
    sys.stdin = FileInput(input_path)
    try:
        print("[Free Fire Spinner] Python runner started")
        print("[project]", project)
        runpy.run_path(os.path.join(project, filename), run_name="__main__")
        print("[Free Fire Spinner] SUCCESS")
    except SystemExit as e:
        print("[Free Fire Spinner] EXIT:", e)
    except Exception:
        traceback.print_exc()
        print("[Free Fire Spinner] ERROR")
